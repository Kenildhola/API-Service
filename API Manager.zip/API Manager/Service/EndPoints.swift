//
//  EndPoints.swift
//  NewDemo
//
//  Created by Ankit Gabani on 07/07/25.
//

import Foundation

// MARK: - EndPointType Protocol -
protocol EndPointType {
    var baseURL: URL { get }
    var path: String { get }
    var httpMethod: HTTPMethod { get }
    var task: HTTPTask { get }
    var headers: HTTPHeaders? { get }
}

// MARK: - AppAPI Enum -
enum AppAPI {
    case <#String#>
}

// MARK: - AppAPI Extension -
extension AppAPI: EndPointType {
    
    var baseURLString: String {
       return <#String#>
    }

    var baseURL: URL {
        guard let url = URL(string: baseURLString) else {
            fatalError("baseURL could not be configured.")
        }
        return url
    }
    
    var path: String {
        switch self {
        case .<#String#>:
            <#String#>
        }
    }
    
    var httpMethod: HTTPMethod {
        switch self {
        case .<#String#>:
            return <#String#>
        }
    }
    
    var task: HTTPTask {
        switch self {
        case .<#String#>:
            return <#String#>
        }
    }
    
    var headers: HTTPHeaders? {
        return nil
    }
    
    
}
