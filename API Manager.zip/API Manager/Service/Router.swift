//
//  Router.swift
//  NewDemo
//
//  Created by Ankit Gabani on 07/07/25.
//

import Foundation

import Foundation

// MARK: - NetworkResponse Enum -
enum NetworkResponse: String {
    case success
    case badRequest = "Bad request."
    case authenticationError = "Authentication is required."
    case failed = "Network request failed."
    case outdated = "The url you requested is outdated."
    case noData = "No data to decode."
    case unableToDecode = "could not decode."
}

// MARK: - Result Enum -
enum Result<String> {
    case success
    case failure(String)
}

// MARK: - Typealiases -
public typealias SuccessHandler = (Data?) -> Void
public typealias FailureHandler = (String?) -> Void

// MARK: - NetworkManager Struct -
struct NetworkManager {
    static let router = Router<AppAPI>()
}

// MARK: - Completion Handler -
public typealias NetworkRouterCompletion = (_ data: Data?, _ response: URLResponse?, _ error: String?)->Void

// MARK: - NetworkRouter Protocol -
protocol NetworkRouter: class {
    associatedtype EndPoint: EndPointType
    func request(_ route: EndPoint, body: Parameters?, completion: @escaping NetworkRouterCompletion)
    func cancel()
}

// MARK: - Router Class -
class Router<EndPoint: EndPointType>: NetworkRouter {
    private var task: URLSessionTask?

    func request(_ route: EndPoint, body: Parameters? = nil, completion: @escaping NetworkRouterCompletion) {
        let session = URLSession.shared
        do {
            let request = try self.buildRequest(from: route, body: body)
            print(request.url ?? "")
            task = session.dataTask(with: request, completionHandler: { data, response, error in
                if error != nil {
                    completion(nil, nil, "Please check your network connection.")
                }
                self.handleResponse(data: data, response: response, completion: completion)
            })
        } catch {
            completion(nil, nil, error.localizedDescription)
        }
        self.task?.resume()
    }

    private func handleResponse(data: Data?, response: URLResponse?,
                                completion: @escaping NetworkRouterCompletion) {
        if let response = response as? HTTPURLResponse {
            let result = self.handleNetworkResponse(response)
            switch result {
            case .success:
                guard let responseData = data else {
                    completion(nil, nil, NetworkResponse.noData.rawValue)
                    return
                }
                completion(responseData, nil, nil)
            case .failure(let networkFailureError):
                completion(nil, nil, networkFailureError)
            }
        }
    }

    fileprivate func handleNetworkResponse(_ response: HTTPURLResponse) -> Result<String> {
        switch response.statusCode {
        case 200...299: return .success
        case 400...499: return .failure(NetworkResponse.authenticationError.rawValue)
        case 500...599: return .failure(NetworkResponse.badRequest.rawValue)
        case 600: return .failure(NetworkResponse.outdated.rawValue)
        default: return .failure(NetworkResponse.failed.rawValue)
        }
    }

    func cancel() {
        self.task?.cancel()
    }

    fileprivate func buildRequest(from route: EndPoint, body: Parameters? = nil) throws -> URLRequest {
        var request = URLRequest(url: route.baseURL.appendingPathComponent(route.path),
                                 cachePolicy: .reloadIgnoringLocalAndRemoteCacheData,
                                 timeoutInterval: 180.0)
        request.httpMethod = route.httpMethod.rawValue
        if let body = body {
            let data = try! JSONSerialization.data(withJSONObject: body as Any, options: .prettyPrinted)
            request.httpBody = data
        }

        do {
            switch route.task {
            case .request:
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            case .requestParameters(_, let bodyEncoding,
                                    let urlParameters):

                try self.configureParameters(bodyParameters: body,
                                             bodyEncoding: bodyEncoding,
                                             urlParameters: urlParameters,
                                             request: &request)

            case .requestParametersAndHeaders(let bodyParameters,
                                              let bodyEncoding,
                                              let urlParameters,
                                              let additionalHeaders):

                self.addAdditionalHeaders(additionalHeaders, request: &request)
                try self.configureParameters(bodyParameters: bodyParameters,
                                             bodyEncoding: bodyEncoding,
                                             urlParameters: urlParameters,
                                             request: &request)
            }
            return request
        } catch {
            throw error
        }
    }

    fileprivate func configureParameters(bodyParameters: Parameters?,
                                         bodyEncoding: ParameterEncoding,
                                         urlParameters: Parameters?,
                                         request: inout URLRequest) throws {
        do {
            try bodyEncoding.encode(urlRequest: &request,
                                    bodyParameters: bodyParameters, urlParameters: urlParameters)
        } catch {
            throw error
        }
    }

    fileprivate func addAdditionalHeaders(_ additionalHeaders: HTTPHeaders?, request: inout URLRequest) {
        guard let headers = additionalHeaders else { return }
        for (key, value) in headers {
            request.setValue(value, forHTTPHeaderField: key)
        }
    }

    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {

        if challenge.previousFailureCount > 0 {
            completionHandler(Foundation.URLSession.AuthChallengeDisposition.cancelAuthenticationChallenge, nil)
        } else if let serverTrust = challenge.protectionSpace.serverTrust {
            completionHandler(Foundation.URLSession.AuthChallengeDisposition.useCredential, URLCredential(trust: serverTrust))
        } else {
           // print("unknown state. error: \(challenge.error)")
            // do something w/ completionHandler here
        }
    }

}
