//
//  HTTPTask.swift
//  NewDemo
//
//  Created by Ankit Gabani on 07/07/25.
//

import Foundation
import Alamofire

// MARK: - HTTPHeaders Typealias -
public typealias HTTPHeaders = [String: String]

// MARK: - HTTPTask Enum -
public enum HTTPTask {
    case request

    case requestParameters(bodyParameters: Parameters?,
        bodyEncoding: ParameterEncoding,
        urlParameters: Parameters?)

    case requestParametersAndHeaders(bodyParameters: Parameters?,
        bodyEncoding: ParameterEncoding,
        urlParameters: Parameters?,
        additionHeaders: HTTPHeaders?)
}
