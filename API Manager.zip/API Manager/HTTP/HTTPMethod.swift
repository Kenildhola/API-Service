//
//  HTTPMethod.swift
//  NewDemo
//
//  Created by Ankit Gabani on 07/07/25.
//

import Foundation

// MARK: - HTTPMethod Enum -
public enum HTTPMethod: String {
    case get     = "GET"
    case post    = "POST"
    case put     = "PUT"
    case patch   = "PATCH"
    case delete  = "DELETE"
}
